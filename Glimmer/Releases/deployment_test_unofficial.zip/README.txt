	April 7, 2019
Hi there! This zipfile is a test release of Glimmer for 64-bit windows.
In other words, this is not fully debugged, or even fully implemented!
It's a shell of what the first official release will be.

Nonetheless, as far as we know, this program should be able to open and run
with the icon loaded and everything as-is. No additional .dll's should be
neccessary for you to get this running, provided your machine architecture is
64-bit windows.

If you are unable to get this to run, please tell us! Be sure to let us know
what error you get, etc.

Thanks, and keep an eye out for the first official release!

	-Glimmer development team
